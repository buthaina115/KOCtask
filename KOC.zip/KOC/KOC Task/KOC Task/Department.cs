﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using static KOC_Task.Models;

namespace KOC_Task
{
    public class Department
    {
        [Key]
        public int DeptID { get; set; }

        [Required]
        [StringLength(50)]
        public string DeptName { get; set; }

        public virtual ICollection<UserProfile> UserProfiles { get; set; }
    
}
}
