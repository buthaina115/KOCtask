﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
namespace KOC_Task
{
    public class KOCDbContext : DbContext

    {
        public KOCDbContext() : base("name=KOCDataBase") { }

        public DbSet<Department> Departments { get; set; }
        public DbSet<UserProfile> UserProfiles { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Department>().HasKey(d => d.DeptID);
            modelBuilder.Entity<UserProfile>().HasKey(u => u.UserID);
            base.OnModelCreating(modelBuilder);
        }

        }
}
