﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.Windows.Forms;
using KOC_Task;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;


namespace KOC_Task
{
    public partial class Form1 : Form
    {
        private KOCDbContext _ctx = new KOCDbContext();
        private int selectedUserID = 1;
        public Form1()
        {

            InitializeComponent();

        
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            LoadDepartment();
            LoadUsers();

        }
        private void LoadDepartment()
        {
            var departments = _ctx.Departments.ToList();
            comboDept.DataSource = departments;
            comboDept.DisplayMember = "DeptName";
            comboDept.ValueMember = "DeptID";
        }

        private void LoadUsers()
        {
            var users = _ctx.UserProfiles.Include(u => u.Department).ToList();
            if (users != null)
            {
                dgvProfiles.DataSource = users.Select(u => new
                {
                    u.UserID,
                    u.FullName,
                    u.Email,
                    BirthDate = u.BirthDate.ToShortDateString(),
                    Departments = u.Department .DeptName
                }).ToList();
            }
        }
        private void LoadUsersToGrid()
        {
            using (var db = new KOCDbContext())
            {
                var users = db.UserProfiles
                              .Include(u => u.Department)
                              .Select(u => new
                              {
                                  u.UserID,
                                  u.FullName,
                                  u.Email,
                                  u.BirthDate,
                                  Department = u.Department.DeptName
                              })
                              .ToList();

                dgvProfiles.DataSource = users;
            }
        }
        private bool ValidateInputs()
        {
            errorProvider1.Clear();
            bool ok = true;

            if (string.IsNullOrWhiteSpace(fullname.Text))
            {
                errorProvider1.SetError(fullname, "Full name is required.");
                ok = false;
            }

            // Email regex
            var emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            if (!Regex.IsMatch(email.Text, emailPattern))
            {
                errorProvider1.SetError(email, "Invalid email format.");
                ok = false;
            }

            DateTime birthDate = dateTimePicker1.Value.Date;
            if (birthDate > DateTime.Today)
            {
                // Attach the error icon to the DateTimePicker control
                errorProvider1.SetError(dateTimePicker1, "Birth date cannot be in the future.");
                ok = false;
            }

            return ok;
        }

        private void fullname_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            string fullName = fullname.Text.Trim();
            string Email = email.Text.Trim();
            DateTime birthDate = dateTimePicker1.Value;
            int departmentId =  (int)comboDept.SelectedValue;

            if (string.IsNullOrEmpty(fullName) || string.IsNullOrEmpty(Email))
            {
                MessageBox.Show("Please enter all required fields.");
                return;
            }

            if (!Email.Contains("@") || !Email.Contains("."))
            {
                MessageBox.Show("Invalid email format.");
                return;
            }

            using (var db = new KOCDbContext())
            {
                var newUser = new UserProfile
                {
                    FullName = fullName,
                    Email = Email,
                    BirthDate = birthDate,
                    DepartmentID = departmentId
                };

                db.UserProfiles.Add(newUser);
                db.SaveChanges();
                MessageBox.Show("User created successfully!");
                //refresh grid 
                LoadUsersToGrid();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            
            ClearForm();
            
        }
        private void ClearForm()
        {
            fullname.Clear();
            email.Clear();
            dateTimePicker1.Value = DateTime.Now;
            comboDept.SelectedIndex = 0;
            selectedUserID = -1;
        }

        
       

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (selectedUserID < 0 || !ValidateInputs()) return;

            var user = _ctx.UserProfiles.Find(selectedUserID);
            if (user != null)
            {
                user.FullName = fullname.Text.Trim();
                user.Email = email.Text.Trim();
                user.BirthDate = dateTimePicker1.Value.Date;
                user.DepartmentID = (int)comboDept.SelectedValue;

                _ctx.SaveChanges();
                LoadUsers();
                ClearForm();
                MessageBox.Show("User updated successfully.");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            if (selectedUserID < 0)
            {
                MessageBox.Show("Please select a user to delete.");
                return;
            }

            var user = _ctx.UserProfiles.Find(selectedUserID);
            if (user != null)
            {
                _ctx.UserProfiles.Remove(user);
                _ctx.SaveChanges();
                LoadUsers();
                ClearForm();
                MessageBox.Show("User deleted.");
            }
        }

        private void test_Click(object sender, EventArgs e)
        {
            try
            {
                using (var db = new KOCDbContext())
                {
                    if (db.Database.Exists())
                        MessageBox.Show("✅ Connected to KOCDataBase!", "Connection Test",
                                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show("❌ KOCDataBase not found or schema mismatch.", "Connection Test",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error connecting to KOCDataBase:\n" + ex.Message, "Connection Test",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnTestCombo_Click(object sender, EventArgs e)
        {
            var list = _ctx.Departments.ToList();
            MessageBox.Show("Depts count: " + list.Count);

            comboDept.DataSource = list;
            comboDept.DisplayMember = "DeptName";
            comboDept.ValueMember = "DeptID";
        }

        private void dgvProfiles_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            var row = dgvProfiles.Rows[e.RowIndex];

            selectedUserID = Convert.ToInt32(row.Cells["UserID"].Value);

            fullname.Text = row.Cells["FullName"].Value.ToString();
            email.Text = row.Cells["Email"].Value.ToString();
            dateTimePicker1.Value = DateTime.Parse(row.Cells["BirthDate"].Value.ToString());
            comboDept.Text = row.Cells["Departments"].Value.ToString();
        }

        private void comboDept_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
